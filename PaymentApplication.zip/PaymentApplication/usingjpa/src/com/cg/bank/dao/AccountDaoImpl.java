package com.cg.bank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.bank.exceptions.AccountNotFoundException;
import com.cg.bank.exceptions.InsuffecientBalanceException;
import com.cg.bank.exceptions.SameAccountException;
import com.cg.bank.model.Account;

public class AccountDaoImpl implements AccountDao{
	String string=null;
	static EntityManagerFactory emf=Persistence.createEntityManagerFactory("usingjpa");
	int row;
	
	@Override
	public void createAccount(Account user){
		// TODO Auto-generated method stub
		EntityManager em=null;
		try {
			em=emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(user);
			em.getTransaction().commit();
		}
		catch(Exception e)
		{
			throw e;
		}
		finally
		{
			if(emf!=null && em!=null)
			{
				em.close();
			}
		}
		
	}

	@Override
	public Account viewAccount(int accountNumber) throws Exception {
		// TODO Auto-generated method stub
		EntityManager em=null;
		Account user=new Account();
		try {
			validateAccount(accountNumber);
			em=emf.createEntityManager();
			user=em.find(Account.class, accountNumber);
			return user;
		}
		catch(Exception e) {
			throw e;
		}
		finally
		{
			if(emf!=null && em!=null)
			{
				em.close();
			}
		}
	}
	@Override
	public boolean addMoney(int accountNumber, int amount) throws Exception{
		// TODO Auto-generated method stub
		EntityManager em=null;
		int temp=0;
		Account user=new Account();
		try {
			validateAccount(accountNumber);
			em=emf.createEntityManager();
			user=em.find(Account.class, accountNumber);
			temp=user.getBalance();
			temp=temp+amount;
			em.getTransaction().begin();
			user.setBalance(temp);
			em.getTransaction().commit();
			return true;
		}
		catch(Exception e)
		{
			throw e;
		}
		finally
		{
			if(emf!=null && em!=null)
			{
				em.close();
			}
		}
	}
	

	@Override
	public boolean transfer(int accountNumber1, int accountNumber2, int amount) throws Exception {
		// TODO Auto-generated method stub
		int temp1=0,temp2=0;
		EntityManager em=null;
			try {

				validateAccount(accountNumber1);
				validateAccount(accountNumber2);
				checkSameAccount(accountNumber1, accountNumber2);
				temp1=getBalance(accountNumber1);
				temp2=getBalance(accountNumber2);
				checkSuffecientBalance(accountNumber1, amount);
				temp1=temp1-amount;
				temp2=temp2+amount;
				em=emf.createEntityManager();
				Account user1=em.find(Account.class, accountNumber1);
				Account user2=em.find(Account.class, accountNumber2);
				em.getTransaction().begin();
				user1.setBalance(temp1);
				user2.setBalance(temp2);
				em.getTransaction().commit();
				return true;
			}
			catch(Exception e)
			{
				throw e;
			}
			finally
			{
				if(emf!=null && em!=null)
				{
					em.close();

				}
			}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> getAllAccounts() throws Exception {
		// TODO Auto-generated method stub
		EntityManager em=null;
		try
		{

			em=emf.createEntityManager();
			Query q=em.createQuery("select e from Account e");
			return q.getResultList();
		}
		catch(Exception e)
		{
			throw e;
		}
		finally
		{
			if(emf!=null && em!=null)
			{
				em.close();

			}
		}
	}
	

	public int getBalance(int accountNumber){
		int balance = 0;
		EntityManager em=null;
		Account user=new Account();
		try {

			em=emf.createEntityManager();
			user=em.find(Account.class, accountNumber);
			balance=user.getBalance();
			return balance;
		}
		catch(Exception e)
		{
			throw e;
		}
		finally
		{
			if(emf!=null && em!=null)
			{
				em.close();

			}
		}
		
	}

	public void checkSameAccount(int accountNumber1, int accountNumber2) throws SameAccountException{
		// TODO Auto-generated method stub
		try {
			if(accountNumber1==accountNumber2)
			{
				throw new SameAccountException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	public void checkSuffecientBalance(int accountNumber1, int amount) throws Exception {
		// TODO Auto-generated method stub
		try {
			int temp=getBalance(accountNumber1);
			if(temp<amount)
			{
				throw new InsuffecientBalanceException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}


	public void validateAccount(int accountNumber) throws Exception {
		// TODO Auto-generated method stub
		EntityManager em=null;
		try
		{

			em=emf.createEntityManager();
			if(em.find(Account.class, accountNumber) == null)
			{
				throw new AccountNotFoundException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		finally
		{
			if(emf!=null && em!=null)
			{
				em.close();
			}
		}
	}
	@Override
	public void closeFactory() {
		emf.close();
	}

}
