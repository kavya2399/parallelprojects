package com.cg.bank.exceptions;
@SuppressWarnings("serial")
public class SameAccountException extends Exception {

	public SameAccountException()
	{
		super("The account numbers entered are same.");
	}

}
