import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddmountComponent } from './addmount.component';

describe('AddmountComponent', () => {
  let component: AddmountComponent;
  let fixture: ComponentFixture<AddmountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddmountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddmountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
