package com.capgemini.bank.tests;

import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;

import com.capg.project.bean.Account;
import com.capg.project.service.AccountService;
import com.capg.project.service.AccountServiceImpl;

class TestingWallet {

	AccountService service=new AccountServiceImpl();
	boolean flag=true;
	@Test
	
	void testcreateAccountDao() {
		try {
		
		Account user=new Account();
		user.setName("karthi");
		user.setEmailid("karthi@gmail.com");
		user.setPhoneNumber(9090909099L);
		if(service.createAccount(user)!=null){
			flag=false;
			}
		assertFalse(flag);
		}
		catch(Exception e)
		{
			System.out.println(e);
			
			
		}
		
		
		
		}		
	}


